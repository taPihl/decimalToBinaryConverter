/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package userSources;
import java.lang.Math;

/**
 *
 * @author ett15289
 */
public class bitArray {
    public boolean bitArray[] = new boolean [32];
    public String strBitArray[] = new String[32];
    int inputNumber;
    short bytes;
    boolean error;
    
    public bitArray(String in_strNumber, boolean in_swapBytes){
        for(int i = 0; i<= 31; i++){
            this.strBitArray[i] = "";
            this.bitArray[i] = false;
        }
        // input string to integer
        try{
            this.inputNumber = Integer.parseInt(in_strNumber);
        }catch(Exception e){
            this.inputNumber = 0;
        }        
        // count bytes
        this.bytes = byteCount.count(this.inputNumber);
        // if negative number carry out twos complement
        if(this.inputNumber < 0){
            this.inputNumber = Math.abs(this.inputNumber) - 1;
            this.toBinary();
            this.invertBits();
        }
        else{
            this.toBinary();
        }
        // swap bytes if specified
        if (in_swapBytes == true){
            this.swapBytes();
        }
        // print bits to array
        this.printValues();
    }
    
    public void toBinary(){      
        boolean start = true;
        int remainder = 0;
        int temp = 0;
        int i = 0;
        int quotient = this.inputNumber;       
        while (start == true){
            if (quotient == 5){
               this.bitArray[i] = true;
               this.bitArray[i + 2] = true;
               start = false;
            }
            else if (quotient == 4){
               this.bitArray[i + 2] = true;
               start = false;
            }
            else if (quotient == 3){
               this.bitArray[i] = true;
               this.bitArray[i + 1] = true;
               start = false;
            }
            else if (quotient == 2){
               this.bitArray[i + 1] = true;
               start = false;
            }
            else if (quotient == 1){
               this.bitArray[i] = true;
               start = false;
            }
            else if (quotient == 0){
               start = false;
            }
            else{
                remainder = quotient % 2;
                if (remainder == 1){
                    this.bitArray[i] = true;
                    temp = quotient - 1;
                    quotient = temp / 2;
                    i++;
                }
                else if(remainder == 0){
                    quotient = quotient / 2;
                    i++;
                }
            }
        }
    }
    
    public void invertBits(){
        for(int i=0; i<=31; i++){
            if(this.bitArray[i] == false){
                this.bitArray[i] = true;
            }
            else if(this.bitArray[i] == true){
                this.bitArray[i] = false;
            }
        }
    }
    
    public void swapBytes(){
        boolean[] auxByte = new boolean[8];
        boolean[] retVal = new boolean[32];
        int startPoint_1  = 8;
        int stopPoint_1  = 15;
        int startPoint_2 = 0;
        int stopPoint_2 = 7;
        int j;
        int i;

        if (this.bytes == 4){
            startPoint_1 = 24;
            stopPoint_1 = 31;
        }
        
        if (this.bytes > 1){
            while (startPoint_1 >= 0){
                j = 0;
                for (i = startPoint_1; i<=stopPoint_1; i++){
                    auxByte[j] = this.bitArray[i];
                    j++;
                }
                j = 0;
                for (i = startPoint_2; i<=stopPoint_2; i++){
                    retVal[i] = auxByte[j];
                    j++;
                }
                startPoint_1 = startPoint_1 - 8;
                stopPoint_1 = stopPoint_1 - 8;
                startPoint_2 = startPoint_2 + 8;
                stopPoint_2 = stopPoint_2 + 8;                
            }        
        }
        this.bitArray = retVal;
    }
    
    public void printValues(){
        int limit = this.bytes * 8 - 1;
        for(int i = 0; i <= 31; i++){
            if (i <= limit && this.bitArray[i] == true){
                this.strBitArray[i] = "TRUE";
            }
            else if (i <= limit && this.bitArray[i] == false){
                this.strBitArray[i] = "FALSE";
            }
        }
    }  
}
