/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package userSources;

/**
 *
 * @author ett15289
 */
public class basicFunc {
    public static int strToInt(String in_strNumber){
        int retVal = 0;
        if(in_strNumber != null && in_strNumber.matches("[0-9.]+")){
            try{
                retVal = Integer.parseInt(in_strNumber);
            }catch(NumberFormatException nfe){
                System.out.println("Failed to convert string to integer");
            }
        }
        return retVal;
    }   
}
