/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package userSources;
import java.util.HashMap;

/**
 *
 * @author ett15289
 */

public class byteCount {
        public static short count(int in_number){
            short byteCount = 0;
            final int[] byteLimits = {-128, 127};
            final int[] shortLimits = {-32768, 32767};
            final int[] intLimits = {-2147483648, 2147483647};
            try{
                if(in_number <= byteLimits[1] && in_number >= byteLimits[0]){
                    byteCount = 1;
                }
                else if (in_number <= shortLimits[1] && in_number >= shortLimits[0]){
                    byteCount = 2;
                }
                else if (in_number <= intLimits[1] && in_number >= intLimits[0]){
                    byteCount = 4;
                }
            }
            catch(Exception e){
                System.out.println("Bytecount definition error");
            }
            return byteCount;
    }  
}
